<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Open Stock For <?php echo e(now()->format('Y-m-d')); ?></title>
</head>
<style>
    @media print {
        .container-sm {
            display: none;
        }

        .container-sm>.table {
            display: block;
        }

    }

    table,
    td,
    tr, th {
        border: 1px solid #222;
        border-collapse: collapse;
    }
</style>

<body>
        <table style="width: 100%">
            <thead>
                <tr>
                    <th colspan="4" class="text-center">Open Stock on <?php echo e($date); ?></th>
                </tr>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Product</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Price</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($key + 1); ?></th>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->quantity); ?></td>
                        <td><?php echo e($product->price); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\pos\resources\views/stocks/stock-view.blade.php ENDPATH**/ ?>