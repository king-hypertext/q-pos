<div class="modal fade" id="view-stock-modal" tabindex="-1" data-bs-backdrop="static" aria-modal="true"
    aria-labelledby="view-stock-modal" data-bs-keyboard="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalCenteredScrollableTitle">Saved Orders:
                    <?php echo e($customer->name); ?></h1>
                
            </div>
            <div class="modal-body">
                <div class="d-flex justify-content-between">
                    <?php if(count($orders) === 0): ?>
                        <tr align="center">
                            <td colspan="4">
                                No Records Found
                            </td>
                        </tr>
                    <?php else: ?>
                        Select date and filter
                    <?php endif; ?>
                    <form id="filter-order" method="post">
                        Filter Order:
                        <input type="date" class="form-control form-control-sm d-inline-block" style="width: auto"
                            value="<?php echo e(Date('Y-m-d')); ?>" max="<?php echo e(Date('Y-m-d')); ?>" name="date" id="date" />
                        <input type="hidden" name="id" value="<?php echo e($customer->id); ?>" />
                        <button type="submit" class="btn btn-sm btn-primary d-inline-block">Filter</button>
                    </form>
                </div>
                <div class="d-flex justify-content-center d-none">
                    <div class="alert alert-danger text-center" style="max-width: 50%!important" id="filter-response">
                    </div>
                </div>

                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                
            </div>
        </div>
    </div>
</div>
<?php if(session('success')): ?>
        <script>
            const showSuccessAlert = Swal.mixin({
                position: 'top-end',
                toast: true,
                timer: 6500,
                showConfirmButton: false,
                timerProgressBar: false,
            });
            showSuccessAlert.fire({
                icon: 'success',
                text: '<?php echo e(session('success')); ?>',
                padding: '10px',
                width: 'auto'
            });
        </script>
    <?php endif; ?>

<script>
    const showSuccessAlert = Swal.mixin({
        position: 'top-end',
        toast: true,
        timer: 6500,
        showConfirmButton: false,
        timerProgressBar: false,
    });

    $(document).ready(function() {
        $('#filter-order').on('submit', function(e) {
            e.preventDefault();
            console.log(e);
            var date = e.currentTarget[0].value;
            $.ajax({
                url: "<?php echo e(route('order.filter')); ?>",
                type: "POST",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "id": e.currentTarget[1].value,
                    "date": date
                },
                success: function(res) {
                    if (res.success) {
                        console.log(res);
                        window.open(res.success + "?date=" + res.date, "_self");
                    } else if (res.empty) {
                        console.log(res.empty);
                        alert(res.empty)
                    }
                },
                error: function(res) {
                    console.log(res);
                }
            })
        });
        $(document).on('keyup', '.u-quantity', function(elem) {
            var name = total = elem.target.parentElement.parentElement.parentElement.children[0]
                .children[0].children[0].children[0].children[0].value;
            var price = elem.target.parentElement.parentElement.parentElement.children[1].children[0]
                .children[0].value,
                total = elem.target.parentElement.parentElement.parentElement.children[3].children[0]
                .children[0];
            quantity = elem.target.value;
            $.ajax({
                method: "GET",
                url: "/product/price?q=" + name,
                success: function(res) {
                    elem.target.max = res.data[0].quantity;
                },
            });
            total.value = price * quantity;
        });
    });
    $(document).on('click', '.btn-delete', function(e) {
        $.ajax({
            url: "/order/delete/" + e.target.id,
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
            },
            success: function(res) {
                console.log("success ", res);
                if (res.success) {
                    location.reload();
                    showSuccessAlert.fire({
                        icon: 'success',
                        text: res.success,
                        padding: '10px',
                        width: 'auto'
                    })
                }
            },
            error: function(res) {
                console.log("error ", res);
            }
        })
    })
</script>

<?php /**PATH C:\xampp\htdocs\laravel\pos\resources\views/modals/view-stock-modal.blade.php ENDPATH**/ ?>