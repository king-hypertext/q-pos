
<?php $__env->startSection('content'); ?>
    <nav>
        <div class="nav nav-tabs mb-3" id="nav-tab" role="tablist">
            <a href="<?php echo e(route('invoice.orders')); ?>" class="nav-link active" aria-selected="true">orders invoices</a>
            <a href="<?php echo e(route('invoice.supliers')); ?>" class="nav-link">suppliers</a>
        </div>
    </nav>
    <?php
        use Carbon\Carbon;
        // dd($invoices);
        // dd($orders);
    ?>
    <div class="table-responsive">
        <table class="table table-striped" id="order_invoice">
            <thead>
                <tr>
                    <th>#invoice Number</th>
                    <th>Date</th>
                    <th>Customer</th>
                    <th>Amount</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($invoice->invoice_number); ?></td>
                        <td><?php echo e(Carbon::parse($invoice->created_at)->format('Y-M-d')); ?></td>
                        <td><?php echo e($invoice->name); ?></td>
                        <td><?php echo e($invoice->amount); ?></td>
                        <td>
                            <a href="<?php echo e(route('invoice.orders.get', [$invoice->token])); ?>" class="btn btn-primary"
                                target="_blank">View</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            new DataTable('#order_invoice', {
                scrollY: false,
                processing: true,
                pageLength: 100,
                
            });
            document.querySelector('input[aria-controls="order_invoice"]').placeholder = "Search table";
            $('input[aria-controls="order_invoice"]').on('keyup', function() {
                table.search(this.value).draw();
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\pos\resources\views/pages/order_invoice.blade.php ENDPATH**/ ?>