<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="<?php echo e(url('logo.png')); ?>" type="image/x-icon" />
    <link rel="apple-touch-icon" href="<?php echo e(url('logo.png')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('assets/fonts/font-awesome/css/all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/jquery-ui-1.13.2/jquery-ui.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/jquery-ui-1.13.2/jquery-ui.structure.min.css')); ?>" />
    <link rel="stylesheet"
        href="<?php echo e(asset('assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2-bootstrap-5-theme.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('assets/plugins/datatables/dataTables.bootstrap5.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('assets/plugins/bootstrap-datepicker/css/bootstrap-datetimepicker.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('assets/plugins/bootstrap-daterangepicker/daterangepicker.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/alert/sweetalert2.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('assets/plugins/mdb/mdb.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('assets/css/bootstrap.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('assets/css/index.css')); ?>" />
    <script src="<?php echo e(asset('assets/plugins/alert/sweetalert2.all.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/jquery-ui-1.13.2/external/jquery/jquery.js')); ?>"></script>
    <title>Q-POS | <?php echo e($title ?? ''); ?></title>
</head>

<body class="overflow-x-hidden">
    <div class="loader-bg">
        <div class="loader-bar">
        </div>
    </div>
    <div class="main-content">
        <aside class="sidebar fixed-top bg-light text-dark" id="sidebar">
            <div class="sidebar-wrapper">
                <ul class="list-unstyled">
                    <li class="nav-item">
                        <a href="<?php echo e(route('dashboard')); ?>" title="Dashboard" class="link nav-link">
                            <i class="fas fa-chevron-right"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('products')); ?>" title="Inventories" class="link nav-link">
                            <i class="fas fa-chevron-right"></i>
                            <span>Inventories</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('customers')); ?>" title="Workers Van" class="link nav-link">
                            <i class="fas fa-chevron-right"></i>
                            <span>Workers Van</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('suppliers')); ?>" title="Suppliers" class="link nav-link">
                            <i class="fas fa-chevron-right"></i>
                            <span>Suppliers</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('orders.customer')); ?>" title="Oders" class="link nav-link">
                            <i class="fas fa-chevron-right"></i>
                            <span>Orders</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('returns')); ?>" title="Returns" class="link nav-link">
                            <i class="fas fa-chevron-right"></i>
                            <span>Returns</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('invoice.orders')); ?>" title="Invoices" class="link nav-link">
                            <i class="fas fa-chevron-right"></i>
                            <span>Invoices</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('settings')); ?>" class="link nav-link">
                            <i class="fas fa-chevron-right"></i>
                            <span>Settings</span>
                        </a>
                    </li>
                </ul>
                <div class="log-status-wrapper">
                    <h4 class="log-status-header text-center h6 p-2">
                        Login Status
                    </h4>
                    <ul class="list-unstyled">
                        <li><span class="fw-semibold"> Login As: </span>
                            <span class="text-capitalize"> <?php echo e(auth()->user()->name); ?></span>
                        </li>
                        <li><span class="fw-semibold"> User Type: </span>
                            <?php echo e(auth()->user()->admin == 1 ? 'Admin' : ''); ?>

                        </li>
                        <li><span class="fw-semibold"> Since: </span> <?php echo e(auth()->user()->login); ?></li>
                        <li><span class="fw-semibold"> Last Logout: </span> <?php echo e(auth()->user()->logout); ?></li>
                    </ul>
                </div>
            </div>
        </aside>
        <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark p-0">
            <div class="container-fluid">
                <a href="javascript:void(0)" class="btn d- d-md-none" data-toggle-nav="sidebar" type="button">
                    <span id="x-toggle" class="fas text-white fa-bars"></span>
                </a>
                <div class="brand-wrapper">
                    <a href="#" class="navbar-brand">
                        <img class="" alt="">Q-POS
                    </a>
                </div>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ms-2">
                        <form class="d-flex my-0 py-0" role="search" action="<?php echo e(url('/search')); ?>" method="GET">
                            <input required name="q" class="form-control form-control-lg form-search me-2"
                                type="search" placeholder="Search for products, customers ..." aria-label="Search">
                            <button class="btn btn-outline-light p-1" title="Search" type="submit"><i
                                    class="fas fa-magnifying-glass"></i></button>
                        </form>
                    </ul>
                </div>
                <div class="dropdown">
                    <a href="javascript:void(0)" class="nav-link" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <?php if(auth()->user()->user_image == ''): ?>
                            <img src="<?php echo e(asset('assets/images/avatar-1.png')); ?>" alt="product-image"
                                class="img-user" />
                        <?php else: ?>
                            <img src="<?php echo e(asset('assets/images/admin/' . auth()->user()->user_image)); ?>"
                                alt="product-image" class="img-user" />
                        <?php endif; ?>
                        <span class="text-white text-capitalize"><?php echo e(auth()->user()->name); ?></span>
                    </a>
                    <ul class="dropdown-menu user-nav shadow outline-0 border-0">
                        <li>
                            <h6 class="dropdown-header">Hello, <span
                                    class="text-capitalize"><?php echo e(auth()->user()->name); ?></span>!
                            </h6>
                        </li>
                        <li><a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>">Notifications</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('settings')); ?>">Settings</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li>
                            <button type="submit" class="btn  dropdown-item shadow-none" data-bs-toggle="modal"
                                data-bs-target="#modal-logout"><i class="fas fa-"></i>
                                <span>Log Out</span>
                            </button>
                        </li>
                    </ul>
                </div>
                <style>
                    .dropdown-menu[data-bs-popper] {
                        right: 0;
                        left: auto;
                        transition: all 0.3s ease-out;
                    }

                    .dropdown-menu.user-nav {
                        right: -15px !important;
                        top: 55px !important;
                    }

                    .dropdown-menu.user-nav.show {
                        border-radius: 0;
                        transition: all 0.3s ease-out;
                    }
                </style>
            </div>
        </nav>
        <div class="container-fluid">
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('modals.logout-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <script src="<?php echo e(url('assets/plugins/bootstrap/js/bootstrap.bundle.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/mdb/js/mdb.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/select2/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/jquery-ui-1.13.2/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/bootstrap-datepicker/js/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/datatables/dataTables.rowGroup.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/datatables/dataTables.bootstrap5.min.js')); ?>"></script>
    
    <script src="<?php echo e(url('assets/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/datatables/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/datatables/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/datatables/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/datatables/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/datatables/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/main.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/menu.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\pos\resources\views/layout/layout.blade.php ENDPATH**/ ?>