
<?php $__env->startSection('content'); ?>
    <style>
        .product-image-view {
            width: 200px;
            height: auto;
            max-height: 200px;
            /* border-radius: 50%; */
            background-size: cover;
            background: #2222;
        }
    </style>
    <?php
        use Carbon\Carbon;
        use App\Models\Suppliers;
        $suppliers = Suppliers::select('category')->get();
    ?>
    <div class="container">
        
        <div class="col-sm-12 col-md-5 mt-3">
            <div class="d-flex justify-content-start">
                <?php if($data->product_image !== ''): ?>
                    <img src="<?php echo e(asset('assets/images/products/' . $data->product_image)); ?>" alt="<?php echo e($data->product_image); ?>"
                        class="product-image-view">
                <?php else: ?>
                    <img src="" alt="product-image" class="product-image-view">
                <?php endif; ?>
                <table class="table table-striped ms-5" id="product-table" style="max-width: 500px">
                    <tr>
                        <th scope="col">ID</th>
                        <td scope="row"><?php echo e($data->id); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Product Name</th>
                        <td><?php echo e($data->product_name); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Unit Price</th>
                        <td><?php echo e($data->price); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Available Qty</th>
                        <td><?php echo e($data->quantity); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Supplied By</th>
                        <td><?php echo e($data->supplier_name); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Expiry Date</th>
                        <td><?php echo e(Carbon::parse($data->expiry_date)->format('Y-M-d')); ?></td>
                    </tr>
                    
                </table>
            </div>
        </div>
        <div class="col-sm-12 col-md-7 mt-4 card shadow border-0">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="d-flex justify-content-center">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="divider my-0">
                <div class="divider-text">
                    <h5 class="h3 text-capitalize">Edit / Update <?php echo e($data->product_name); ?></h5>
                </div>
            </div>
            <div class="d-flex justify-content-center">
                <img id="product-image" src="" alt="Product Image"
                    class="rounded-circle product-image bg-light d-none" />
            </div>
            <form class="px-5 py-2" action="<?php echo e(route('product.update', [$data->id])); ?>" method="POST"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-outline mb-4">
                    <input required type="text" value="<?php echo e($data->product_name); ?>" name="product-name" id="productName"
                        class="form-control" />
                    <label class="form-label" for="productName">Product Name</label>
                </div>
                <div class="form-outline mb-4">
                    <input required type="text" value="<?php echo e($data->price); ?>" onfocus="this.type='number'"
                        name="unit-price" id="unitPrice" class="form-control" />
                    <label class="form-label" for="unitPrice">Unit Price</label>
                </div>
                <div class="row mb-4">
                    <div class="col-6">
                        <div class="form-outline">
                            <input disabled type="text" value="<?php echo e($data->quantity); ?>" onfocus="this.type='number'"
                                name="qty" id="quantity" class="form-control" />
                            <label class="form-label" for="quantity">Available Quantity</label>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-outline">
                            <input type="text" value="<?php echo e($data->batch_number); ?>" name="batch-number" id="batchNumber"
                                class="form-control" />
                            <label class="form-label" for="batchNumber">Batch Number</label>
                        </div>
                    </div>
                </div>
                <div class="form-outline mb-4">
                    <label for="supplier" class="form-label">Supplier</label>
                    <select required name="supplier" id="supplier" class="form-select">
                        <option selected value="<?php echo e($data->supplier_name); ?>"><?php echo e($data->supplier_name); ?></option>
                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($supplier->category); ?>"><?php echo e($supplier->category); ?></option>
                            <?php if($data->supplier_name == 'shell'): ?>
                            <?php elseif($data->supplier_name == 'allied'): ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="row mb-4">
                    <div class="col-6">
                        <label class="form-label" for="productionDate">Manufacturing Date</label>
                        <input type="date" value="<?php echo e($data->prod_date); ?>" max="<?php echo e(Date('Y-m-d')); ?>" name="prod-date"
                            id="productionDate" class="form-control" />
                    </div>
                    <div class="col-6">
                        <label class="form-label" for="expiryDate">Expiry Date</label>
                        <input required type="date" value="<?php echo e($data->expiry_date); ?>" min="<?php echo e(Date('Y-m-d')); ?>"
                            name="exp-date" id="expiryDate" class="form-control" />
                    </div>
                </div>
                <div class="image-preview-wrapper">
                    <img src="" alt="" class="image-preview" style="width: 55px; height: 55px;">
                </div>
                <div class="mb-4">
                    <label for="productImage">Product Image</label>
                    <input type="file" onchange="previewImage()" name="product-image" id="productImage"
                        class="form-control" accept="image/*" />
                </div>
                <button type="submit" class="btn btn-primary btn-block">Update Product</button>
            </form>
        </div>
    </div>
    <script>
        var img_wrapper = $('.image-preview-wrapper');
        img_wrapper.hide();

        function previewImage() {
            var image = document.querySelector('img.image-preview');
            const input = document.getElementById('productImage');
            const file = input.files[0];
            console.log(image);
            const filereader = new FileReader();
            filereader.addEventListener('load', (e) => {
                image.src = e.target.result;
                img_wrapper.show();
            });
            filereader.readAsDataURL(file);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php if(session('success')): ?>
        <script>
            const showSuccessAlert = Swal.mixin({
                position: 'top-end',
                toast: true,
                timer: 6500,
                showConfirmButton: false,
                timerProgressBar: false,
            });
            showSuccessAlert.fire({
                icon: 'success',
                text: '<?php echo e(session('success')); ?>',
                padding: '10px',
                width: 'auto'
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\pos\resources\views/pages/view-product.blade.php ENDPATH**/ ?>