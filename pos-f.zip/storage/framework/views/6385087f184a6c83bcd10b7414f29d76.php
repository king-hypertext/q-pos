
<?php $__env->startSection('content'); ?>
    Settings
    <style>
        .product-image-view {
            width: 200px;
            height: auto;
            border-radius: 50%;
            background-size: cover;
            background: #2222;
        }
    </style>
    <div class="container">
        <div class="row">
            <div class="col-6 col-md-6">
                <div class="d-flex justify-content-center">
                    <?php if(auth()->user()->user_image == ''): ?>
                        <img src="<?php echo e(asset('assets/images/avatar-1.png')); ?>" alt="product-image" class="product-image-view">
                    <?php else: ?>
                        <img src="<?php echo e(asset('assets/images/admin/' . auth()->user()->user_image)); ?>" alt="product-image"
                            class="product-image-view">
                    <?php endif; ?>
                </div>
                <h6 class="h5 text-center"><?php echo e(auth()->user()->name); ?></h6>
            </div>
            <div class="col-6 col-md-6">
                <div class="card shadow border-0">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="d-flex justify-content-center">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <h5 class="h5 text-center pt-5">User Profile</h5>
                    <form class="px-5 py-2" action="<?php echo e(url('/update-profile')); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-outline mb-4">
                            <input required type="text" value="<?php echo e(auth()->user()->name); ?>" name="name" id="name"
                                class="form-control form-control-lg" />
                            <label class="form-label" for="name">User Name</label>
                        </div>
                        <div class="form-outline mb-4">
                            <input required type="text" value="<?php echo e(auth()->user()->username); ?>" name="user-name"
                                id="user-name" class="form-control form-control-lg" />
                            <label class="form-label" for="user-name">User Name</label>
                        </div>
                        <div class="form-outline mb-4">
                            <input required type="text" value="<?php echo e(auth()->user()->date_of_birth); ?>"
                                onfocus="this.type='date'" name="dob" id="dob"
                                class="form-control form-control-lg" />
                            <label class="form-label" for="dob">Date of Birth</label>
                        </div>
                        <div class="form-outline mb-4">
                            <input disabled type="text" value="admin" name="user-type" id="batchNumber"
                                class="form-control form-control-lg" />
                            <label class="form-label" for="batchNumber">User Type</label>
                        </div>
                        <div class="d-flex justify-content-center">
                            <img id="product-image" src="" alt="Product Image"
                                class="rounded-circle product-image bg-light d-none" />
                        </div>
                        <div class="form-outline mb-4">
                            <input required type="password" name="password" id="user-password"
                                class="form-control form-control-lg" />
                            <label class="form-label" for="user-password">New Password</label>
                        </div>
                        <div class="mb-4">
                            <label for="userImage">Profile Image</label>
                            <input type="file" onchange="previewImage()" name="user-image" id="userImage"
                                class="form-control" />
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Update Profile</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php if(session('success')): ?>
        <script>
            const showSuccessAlert = Swal.mixin({
                position: 'top-end',
                toast: true,
                timer: 6500,
                showConfirmButton: false,
                timerProgressBar: false,
            });
            showSuccessAlert.fire({
                icon: 'success',
                text: '<?php echo e(session('success')); ?>',
                padding: '10px',
                width: 'auto'
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function previewImage() {
            var image = document.getElementById('product-image');
            const input = document.getElementById('userImage');
            const file = input.files[0];
            console.log(file);
            const filereader = new FileReader();
            filereader.readAsDataURL(file);
            filereader.addEventListener('load', () => {
                // image.classList.remove('d-none')
                // console.log(this.result);
                image.src = this.result;
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\pos\resources\views/pages/settings.blade.php ENDPATH**/ ?>