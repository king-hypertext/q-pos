
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="card p-5 border-0 mt-5" style="max-width: 520px">
                <form action="<?php echo e(url('/auth/login')); ?>" method="POST" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="text-center">
                        <img src="<?php echo e(url('logo.png')); ?>" style="height: 80px" alt="logo">
                        <h5 class="h4 text-uppercase text-danger">shell medyak mr b.</h5>
                    </div>
                    <h3 class="text-center text-primary py-2">
                        Login to your account
                    </h3>
                    <?php if(session('login')): ?>
                        <div class="alert alert-warning text-warning"><?php echo e(session('login')); ?></div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <h6 class="h6 text-danger text-center"><?php echo e(session('error')); ?></h6>
                    <?php endif; ?>
                    <div class="form-outline mb-4">
                        <input required type="text" autofocus name="username" id="username" class="form-control form-control-lg" />
                        <label class="form-label" for="username">Username</label>
                    </div>
                    <div class="form-outline mb-4">
                        <input required type="password" name="password" id="password"
                            class="form-control form-control-lg" />
                        <label class="form-label" for="password">Password</label>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-lg btn-primary btn-block">Secure Login</button>
                    </div>
                </form>
                <div class="form-text">
                    Forgotten Password? <a href="<?php echo e(url('/auth/reset-password')); ?>" title="Click to reset your password"
                        class="btn-link">Reset</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\pos\resources\views/auth/login.blade.php ENDPATH**/ ?>