<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="<?php echo e(asset('logo.png')); ?>" type="image/x-icon" />
    <link rel="apple-touch-icon" href="<?php echo e(asset('logo.png')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('assets/fonts/font-awesome/css/all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('assets/plugins/mdb/mdb.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('assets/css/bootstrap.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('assets/css/index.css')); ?>">
    <script src="<?php echo e(url('assets/plugins/jquery-ui-1.13.2/external/jquery/jquery.js')); ?>"></script>
    <title>Q-POS | <?php echo e($title ?? ''); ?></title>
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
<script src="<?php echo e(url('assets/plugins/mdb/js/mdb.min.js')); ?>"></script>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\pos\resources\views/auth/layout.blade.php ENDPATH**/ ?>