
<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
        <table class="table table-borderless mb-0">
            <tr>
                <th></th>
                <th colspan="7" class="text-center">Quantity</th>
            </tr>
            <tr>
                <th>Customer Name</th>
                <th>Product</th>
                <th>Monday</th>
                <th>Tuesday</th>
                <th>Wednesday</th>
                <th>Thursday</th>
                <th>Friday</th>
                <th>Saturday</th>
                <th>Sunday</th>
                <th>Total</th>
                <th>Returns</th>
                <th>Sold</th>
                <th>Amount</th>
            </tr>
                       
            <tr>
                <td class="text-end fw-bold" colspan="11">Total</td>
                <td>00.00</td>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\pos\resources\views/pages/stocks.blade.php ENDPATH**/ ?>