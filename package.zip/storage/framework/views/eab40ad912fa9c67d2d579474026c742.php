<div class="modal fade" id="issue-stock" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
    aria-labelledby="modal-issue-stock" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="dialog">
        <div class="modal-content rounded-3 shadow">
            <div class="modal-body p-2">
                <div class="row justify-content-center">
                    <div class="divider my-0">
                        <div class="divider-text">
                            <h5 class="h3 text-capitalize">Add New Customer</h5>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center">
                        <img id="customer-image" src="" alt="Product Image" class="rounded-circle product-image bg-light d-none" />
                    </div>
                    <form class="px-5 py-2" action="<?php echo e(url('/add-customer')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-outline mb-4">
                            <input type="text" name="customer-name" id="customertName" class="form-control" />
                            <label class="form-label" for="customertName">Customer Name</label>
                        </div>
                        <div class="row mb-4">
                            <div class="col-6">
                                <label class="form-label" for="dob">Date of Birth</label>
                                <input type="date" max="<?php echo e(Date('Y-m-d')); ?>" name="customer-dob" id="dob"
                                    class="form-control" />
                            </div>
                            <div class="col-6">
                                <label class="form-label" for="gender">Gender</label>
                                <select name="gender" id="gender" class="form-select">
                                    <option selected disabled>Select Gender</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-outline mb-4">
                            <input type="text" onfocus="this.type='number'" name="customer-contact"
                                id="customerContact" class="form-control" />
                            <label class="form-label" for="customerContact">Contact</label>
                        </div>
                        <div class="form-outline mb-4">
                            <input type="text" name="customer-address" id="customerAddress" class="form-control" />
                            <label class="form-label" for="customerAddress">Address</label>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Add Customer</button>
                    </form>
                </div>
            </div>
            <div class="d-flex my-0 pb-2 pe-2 justify-content-end">
                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Discard</button>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function previewImage() {
        var image = document.getElementById('customer-image');
        const input = document.getElementById('productImage');
        const file = input.files[0];
        const filereader = new FileReader();
        filereader.readAsDataURL(file);
        filereader.addEventListener('load', () => {
            // console.log(this.result);
            image.src = this.result;
        });
    }
</script>
<?php /**PATH C:\xampp\htdocs\laravel\pos\resources\views/modals/issue-stock.blade.php ENDPATH**/ ?>