
<?php $__env->startSection('content'); ?>
    customer profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\pos\resources\views/pages/view-customer.blade.php ENDPATH**/ ?>