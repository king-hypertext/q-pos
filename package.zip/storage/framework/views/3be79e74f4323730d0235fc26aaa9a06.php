
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="card p-5 border-0 mt-5" style="max-width: 520px">
                <form action="<?php echo e(url('/auth/reset-password')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <h3 class="h5 text-center text-primary py-2">
                        Reset Your Password
                    </h3>
                    <?php if($errors->any()): ?>
                    <div style="z-index: 1"
                        class="animate__animated animate__zoomIn alert alert-danger p-1 rounded-0 text-center">
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-danger"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                    <?php if(session('error')): ?>
                        <h6 class="h6 text-danger text-center"><?php echo e(session('error')); ?></h6>
                    <?php endif; ?>
                    <div class="form-group mb-4">
                        <label for="user">Enter your date of birth</label>
                        <input autofocus type="date" name="dob" id="user" class="form-control" />
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-lg btn-primary btn-block">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\pos\resources\views/auth/reset.blade.php ENDPATH**/ ?>