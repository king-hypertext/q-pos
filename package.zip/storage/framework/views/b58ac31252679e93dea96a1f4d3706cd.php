
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="divider my-0">
                <div class="divider-text">
                    <h5 class="h3 text-capitalize">Update Customer Profile</h5>
                </div>
            </div>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="d-flex justify-content-center">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="d-flex justify-content-center">
                <img id="customer-image" src="" alt="Product Image"
                    class="rounded-circle product-image bg-light d-none" />
            </div>
            <form class="px-5 py-2" action="<?php echo e(route('customer.edit')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                <div class="form-outline mb-4">
                    <input required type="text" value="<?php echo e($data->customer_name); ?>" name="customer-name"
                        id="customertName" class="form-control form-control-lg" />
                    <label class="form-label" for="customertName">Customer Name</label>
                </div>
                <div class="row mb-4">
                    <div class="col-6">
                        <label class="form-label" for="dob">Date of Birth</label>
                        <input required type="date" value="<?php echo e($data->date_of_birth); ?>" max="<?php echo e(Date('Y-m-d')); ?>"
                            name="customer-dob" id="dob" class="form-control" />
                    </div>
                    <div class="col-6">
                        <label class="form-label" for="gender">Gender</label>
                        <select required name="gender" id="gender" class="form-select">
                            <?php if($data->gender == 'male'): ?>
                                <option selected><?php echo e($data->gender); ?></option>
                                <option value="female">Female</option>
                            <?php elseif($data->gender == 'female'): ?>
                                <option value="<?php echo e($data->gender); ?>" selected><?php echo e($data->gender); ?></option>
                                <option value="male">Male</option>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>

                <div class="form-outline mb-4">
                    <input required type="text" value="<?php echo e($data->contact); ?>" onfocus="this.type='number'"
                        name="customer-contact" id="customerContact" class="form-control form-control-lg" />
                    <label class="form-label" for="customerContact">Contact</label>
                </div>
                <div class="form-outline mb-4">
                    <input required type="text" value="<?php echo e($data->address); ?>" name="customer-address" id="customerAddress"
                        class="form-control form-control-lg" />
                    <label class="form-label" for="customerAddress">Address</label>
                </div>
                <div class="mb-4">
                    <label for="customerImage">Customer Image</label>
                    <input type="file" onchange="previewImage()" name="customer-image" accept="image/*"
                        id="customerImage" class="form-control" />
                </div>
                <button type="submit" class="btn btn-lg w-50 btn-primary btn-block">Update Profile</button>
            </form>
        </div>
    </div>
    <?php if(session('success')): ?>
        <script>
            const showSuccessAlert = Swal.mixin({
                position: 'top-end',
                toast: true,
                timer: 6500,
                showConfirmButton: false,
                timerProgressBar: false,
            });
            showSuccessAlert.fire({
                icon: 'success',
                text: '<?php echo e(session('success')); ?>',
                padding: '10px',
                width: 'auto'
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\pos\resources\views/pages/edit-customer.blade.php ENDPATH**/ ?>