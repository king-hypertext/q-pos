/*Template Name: Quantum Able Bootstrap 4 Admin Template
 Author: Codedthemes
 Email: support@phopenixcoded.net
 File: menu.js
 */
"use strict";
$(document).ready(function() {
  
});

