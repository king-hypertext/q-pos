
<?php $__env->startSection('content'); ?>
    <?php
        use Illuminate\Support\Facades\DB;
        use Carbon\Carbon;
        $products = DB::table('products')->get(['name']);
    ?>
    <div class="card shadow border-0">
        <h1 class="card-title text-center">
            <?php echo e($supplier->name); ?> - Order date:
            <?php
                echo Carbon::parse($date)->format('Y-M-d');
            ?>
        </h1>
        <div class="card-body">
            <form id="form-invoice" action="<?php echo e(route('order.supplier.save', [$supplier->id])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="supplier_id" value="<?php echo e($supplier->id); ?>"/>
                <input type="hidden" name="supplier" value="<?php echo e($supplier->name); ?>"/>
                <input type="hidden" name="date" value="<?php echo e(Date('Y-m-d')); ?>"/>
                <input type="hidden" name="order_date" value="<?php echo e($date); ?>"/>
                <input type="hidden" name="supplier-invoice" value="<?php echo e($invoice_number); ?>">
                <input type="hidden" name="category" value="<?php echo e($category); ?>">
                <hr class="hr text-dark" />
                <div class="table-responsive text-nowrap">
                    <table class="table table-borderless mb-0">
                        <thead>
                            <tr class="">
                                <th class="col-md-4" scope="col">Product Name</th>
                                <th class="col-md-3" scope="col" title="Price">Unit Price</th>
                                <th class="col-md-2" scope="col">Quantity</th>
                                <th class="col-md-3" scope="col">Total (GHC)</th>
                            </tr>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="form_row">
                                    <td class="col-md-4">
                                        <div class="">
                                            <div class="">
                                                <div class="form-group">
                                                    <select required data-select-product name="product[]"
                                                        id="product_<?php echo e($index + 1); ?>" class="form-select">
                                                        <option selected> <?php echo e($order->product); ?> </option>
                                                        
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="col-md-3">
                                        <div class="form-group">
                                            <input readonly type="number" name="price[]" type="text"
                                                value="<?php echo e($order->price); ?>" id="price_<?php echo e($index + 1); ?>"
                                                class="form-control u-price" value="0" />
                                        </div>
                                    </td>
                                    <td class="col-md-2">
                                        <div class="form-group">
                                            <input required type="number" name="quantity[]"
                                                id="quantity_<?php echo e($index + 1); ?>" class="form-control u-quantity"
                                                value="<?php echo e($order->quantity); ?>" />
                                        </div>
                                    </td>
                                    <td class="col-md-3">
                                        <div class="form-group">
                                            <input readonly type="text" value="<?php echo e($order->amount); ?>" name="total[]"
                                                id="total_<?php echo e($index + 1); ?>" class="form-control u-total" />
                                        </div>
                                    </td>
                                    <td>
                                        <button class="btn btn-danger btn-delete" id="<?php echo e($order->id); ?>"
                                            value="<?php echo e($order->id); ?>" type="button" title="delete order">delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer justify-content-between mt-3">
                    <div class="px-0">
                    </div>
                    <button type="submit" class="btn btn-success text-capitalize" title="add invoice">Save Order</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        const showSuccessAlert = Swal.mixin({
            position: 'top-end',
            toast: true,
            timer: 6500,
            showConfirmButton: false,
            timerProgressBar: false,
        });
        $(document).on('click', '.btn-delete', function(e) {
            $.ajax({
                url: "/order/supplier/saved/delete/" + e.target.id,
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                },
                success: function(res) {
                    console.log("success ", res);
                    if (res.success) {
                        location.reload();
                        showSuccessAlert.fire({
                            icon: 'success',
                            text: res.success,
                            padding: '10px',
                            width: 'auto'
                        })
                    }
                },
                error: function(res) {
                    console.log("error ", res);
                }
            })
        });
        $(document).ready(function() {
            $(document).on('keyup', '.u-quantity', function(elem) {
                var name = total = elem.target.parentElement.parentElement.parentElement.children[0]
                    .children[0].children[0].children[0].children[0].value;
                var price = elem.target.parentElement.parentElement.parentElement.children[1].children[0]
                    .children[0].value,
                    total = elem.target.parentElement.parentElement.parentElement.children[3].children[0]
                    .children[0];
                quantity = elem.target.value;
                $.ajax({
                    method: "GET",
                    url: "/product/price?q=" + name,
                    success: function(res) {
                        elem.target.max = res.data[0].quantity;
                    },
                });
                total.value = price * quantity;
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\pos\resources\views/pages/view-suppplier-order.blade.php ENDPATH**/ ?>